# PROJ_SUZ
➜ echo "# PROJ_SUZ" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin git@github.com:dancarlosazevedo/PROJ_SUZ.git
git push -u origin main